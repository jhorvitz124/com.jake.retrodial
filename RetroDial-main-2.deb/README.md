# RetroDial
RetroDial brings a classic rotary dialer interface to your iPhone for making calls. With this tweak, you can replace the standard phone keypad with a retro rotary dialer, giving your iPhone a nostalgic feel.


# Features
Replace the standard phone keypad with a rotary dialer interface.
Realistic rotary dialer animation and sound effects.
Option to enable/disable the tweak from Settings.
Compatible with all iPhone models.
